from kivy.app import App


class CalculadoraApp(App):
    def build(self):
        self.expression = ""
        return super().build()

    def on_button_press(self, value):
        if value == "C":
            self.expression = ""
            self.root.ids.display.text = "0"
            return

        if value == "=":
            if not self.expression:
                self.root.ids.display.text = "0"
                return
            try:
                result = str(eval(self.expression, {"__builtins__": {}}, {}))
                self.expression = result
                self.root.ids.display.text = result
            except Exception:
                self.expression = ""
                self.root.ids.display.text = "Error"
            return

        self.expression += value
        self.root.ids.display.text = self.expression


if __name__ == '__main__':
    CalculadoraApp().run()
